﻿namespace ProjetoMongoDB.Models
{
    public class MonfoIdentityRole
    {
    }
}